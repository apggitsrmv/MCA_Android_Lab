/** Automatically generated file. DO NOT MODIFY */
package com.example.android_practical1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}